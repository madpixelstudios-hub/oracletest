#include <fstream>

#include "main.h"
#include "reports.h"
#include "terrain.h"
#include "model.h"

const char Bulldozer::c_directions[4] = { 'u', 'r', 'd',  'l' };

const array<TerrainInfo, 5> Terrain::c_info =
{
	// terrain type,		fuel usage,	credit cost
		TERRAIN_PLAIN,			1,		   	1,			vec3(1,1,0),
		TERRAIN_ROCK,			2,			1,			vec3(1,0,0),
		TERRAIN_TREE,			2,		 	2,			vec3(0,1,0),
		TERRAIN_PTREE,			2,			10,			vec3(0,1,1),
		TERRAIN_VISIT,			1,			1,			vec3(1,1,1),
};

Terrain::~Terrain()
{
	if (m_siteMap)
		delete [] m_siteMap;
	if (m_square)
		delete m_square;
}

bool Terrain::OpenFile(char *fileName)
{
	ifstream file(fileName);
    string str; 

	if (file == NULL)
	{
		cout << "Error: Could not find file!" << endl;
		return false;
	}

	if (m_siteMap != NULL)
	{
		this->~Terrain();
		Terrain();
	}
	m_columns = m_rows = 0;

	while (true)
	{
		if (getline(file, str) == NULL)
			break;
		if (m_columns == 0)
			m_columns = str.length();
		m_rows++;
		if (m_columns == 0)
		{
			cout << "Error: File contains no data!" << endl;
			file.close();
			return false;
		}
	}

	if (m_columns == 0 || m_rows == 0)
	{
		cout << "Error: File contains invalid data!" << endl;
		file.close();
		return false;
	}

	m_siteMap = new char[m_columns*m_rows];
	file.clear();
	file.seekg(0, ios::beg);

	int ofs = 0;
	while (true)
	{
		if (getline(file, str) == NULL)
			break;
		memcpy(&m_siteMap[ofs],str.c_str(),m_columns);
		ofs += m_columns;
	}

	file.close();

	return true;
}

void Terrain::CreateModels()
{
	const GLfloat vertices[] = { 
		-1.0f, -1.0f, 0.0f,
		1.0f, -1.0f, 0.0f,
		-1.0f, 1.0f, 0.0f,
		1.0f, 1.0f, 0.0f,
	};
	m_square = new Model(vertices, sizeof(vertices));
	m_square->CreateProgram("simple");
	const GLfloat vertices2[] = { 
		-1.0f, -1.0f, 0.0f,
		1.0f, -1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
	};
}

void Terrain::DrawMap(Bulldozer &bull, Window *wgl)
{
	for (int r=0;r<m_rows;r++)
	{
		for (int c=0;c<m_columns;c++)
		{
			if (wgl != NULL && m_square != NULL)
			{
				// draw terrain square
				const float scale = 2.5f;
				mat4 trans = translate(mat4(1.f), vec3(c*scale,r*scale,0));
				m_square->SetWorld(trans);
				m_square->SetParam("color", GetInfo(c, r)->color);
				m_square->Draw(wgl);

				// draw bulldozer arrow
				if (c == bull.GetX() && r == bull.GetY())
					bull.Draw(c,r,wgl);
			}
			else
			{
				if (c == bull.GetX() && r == bull.GetY())
					cout << "X";		// bulldozer
				else
					cout << GetType(c, r);	// terrain
			}
		}
		cout << endl;
	}
	cout << endl;
}


void Terrain::Clear(int x, int y)
{
	if (x < 0 || x >= m_columns)
		return;
	if (y < 0 || y >= m_rows)
		return;

	m_siteMap[y*m_columns+x] = TERRAIN_VISIT;
}


char Terrain::GetType(int x, int y)
{
	if (x < 0 || x >= m_columns)
		return 0;
	if (y < 0 || y >= m_rows)
		return 0;

	char type = m_siteMap[y*m_columns+x];
	return type;
}


const TerrainInfo* Terrain::GetInfo(int x, int y)
{
	char type = GetType(x,y);
	if (type == 0)
		return NULL;
	for ( auto it = c_info.begin(); it != c_info.end(); ++it )
	{
		if (it->type == type)
		{
			return &*it;
		}
	}
	return NULL;
}


int Terrain::GetFuelUsage(int x, int y)
{
	const TerrainInfo *info = GetInfo(x, y);
	if (info != NULL)
		return info->usage;
	return 0;
}


void Terrain::FindUncleared(CostReport &costRep)
{
	for (int r=0;r<m_rows;r++)
	{
		for (int c=0;c<m_columns;c++)
		{
			const TerrainInfo *info = GetInfo(c, r);
			if (info->type != TERRAIN_VISIT)
				costRep.AddUnclearedCost(info->cost);
		}
	}
}


///////////////////////
Bulldozer::~Bulldozer()
{
	if (m_arrow)
		delete m_arrow;
}

void Bulldozer::CreateModels()
{
	const GLfloat vertices2[] = { 
		-1.0f, -1.0f, 0.0f,
		1.0f, -1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
	};
	m_arrow = new Model(vertices2, sizeof(vertices2));
	m_arrow->CreateProgram("simple");
}

void Bulldozer::Draw(int c, int r, Window *wgl)
{
	const float scale = 2.5f;
	mat4 rot = translate(mat4(1.f), vec3(c*scale,r*scale,0));
	const float angle = (m_dir+2) * (pi<float>()/2.f);
	rot = rotate(rot, angle, vec3(0,0,1));
	m_arrow->SetWorld(rot);
	m_arrow->SetParam("color", vec3(1,0,1));
	m_arrow->Draw(wgl);
}

int Bulldozer::Move(int count, Terrain &terrain, CostReport &costRep)
{
	int dx = 0, dy = 0;
	switch (c_directions[m_dir])
	{
		case 'u':
			dy = -count;
			break;
		case 'd':
			dy = count;
			break;
		case 'l':
			dx = -count;
			break;
		case 'r':
			dx = count;
			break;
	}

	// we know we can only move horizontally OR vertically
	// so process both at the same time
	int x = m_x;
	m_x += dx;
	int dirX = 0;
	if (dx)
		dirX = dx > 0 ? 1 : -1;
	int y = m_y;
	m_y += dy;
	int dirY = 0;
	if (dy)
		dirY = dy > 0 ? 1 : -1;
	while (x != m_x || y != m_y)
	{
		x += dirX;
		y += dirY;
		const TerrainInfo *info = terrain.GetInfo(x, y);
		if (info == NULL)
			return -1;	// out of bounds
		costRep.AddCost(info);
		terrain.Clear(x, y);
		if (info->type == 'T')
			return -2;	// protected tree
	}

	return 0;
}

