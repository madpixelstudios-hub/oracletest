#pragma once

#include "main.h"

class Window;

class Model
{
	GLuint m_program, m_array, m_buffer;
	int m_count;
	mat4 m_world;

	GLuint LoadCode(const char *filename, bool vertex);

public:
	Model(const GLfloat *data, int size);
	~Model();

	// matrices
	void SetWorld(mat4 mat) { m_world = mat; }
	mat4 GetWorld() { return m_world; }

	// shader program
	void CreateProgram(const char *name);
	void SetParam(const char *name, vec3 vec);
	void SetParam(const char *name, mat4 mat);

	void Draw(Window *wgl);
};
