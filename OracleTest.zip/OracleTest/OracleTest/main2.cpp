#include "gll.h"
#include "glm.h"

#include "glm/gtc/matrix_transform.hpp"

int main( void )
{
	GLLIB gll;
	int r = gll.CreateWindow("OpenGL Test", 800, 800);
	if (r < 0)
		return r;

	gll.SetClearColor(glm::vec4(0,0.4f,0,0));

	static const GLfloat verts[] = { 
		-1.0f, -1.0f, 0.0f,
		 1.0f, -1.0f, 0.0f,
		 -1.0f, 1.0f, 0.0f,
		 1.0f, 1.0f, 0.0f,
	};
	static const GLfloat uvs[] = { 
		0.0f, 0.0f,
		1.0f, 0.0f,
		0.0f, 1.0f,
		1.0f, 1.0f,
	};
	queue<GLMODEL::Buffer> bufs;
	GLMODEL::Buffer bv = { verts, sizeof(verts), 3 };
	GLMODEL::Buffer bu = { uvs, sizeof(uvs), 2 };
	bufs.push(bv);
	bufs.push(bu);
	GLMODEL* square = new GLMODEL(&gll);
	square->CreateBuffers(bufs, GL_TRIANGLE_STRIP);
	square->CreateProgram("simple");
	GLuint color = square->GetParam("diffuse");
	square->AddTexture("diffuse");
	square->AddTexture("specular");

	// Camera matrix
#if 0
	// Proj matrix : 45� Field of View, 4:3 ratio, near/far clip
	glm::mat4 Projection = glm::perspective(glm::radians(45.0f), 4.0f / 3.0f, 1.0f, 100.0f);
	glm::mat4 View       = glm::lookAt(
								glm::vec3(4,4,4), // Camera is at (4,3,3), in World Space
								glm::vec3(0,0,0), // and looks at the origin
								glm::vec3(0,1,0)  // Head is up (set to 0,-1,0 to look upside-down)
						   );
#else
	// Ortho matrix :
	const float scale = 10.f;
	mat4 Projection = ortho(-scale,scale,-scale,scale,0.0f,scale*10.f); // In world coordinates
	float twoPI = pi<float>() * 2.f;
	mat4 Iso = mat4(
				vec4(sin(twoPI/3.f),cos(twoPI/3.f),0,0),
				vec4(sin(2.f*twoPI/3.f),cos(2.f*twoPI/3.f),0,0),
				vec4(0,1,1,0),
				vec4(0,0,0,1)
			);
	gll.SetView(Iso);
	gll.SetProj(Projection);
#endif

	while( gll.RunFrame() )
	{
		gll.StartFrame();

		static float r=0;
		r+=0.01f;
		if (r > 1) r=0;
		square->SetParam(color, vec4(r,r,r,1));
		square->Draw();

		gll.EndFrame();
	}

	delete square;

	gll.DestroyWindow();

	return 0;
}

