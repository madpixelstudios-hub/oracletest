#include <queue>


///////////////////////
class CommandReport
{
	struct Info { char cmd; int moves; Info(char c, int m) { cmd = c; moves = m; } };
	queue<Info> m_data;

public:
	void Advance(int moves)  { m_data.push(Info(CMD_ADV, moves)); }
	void Left() { m_data.push(Info(CMD_LEFT, 0)); }
	void Right() { m_data.push(Info(CMD_RIGHT, 0)); }
	void Quit() { m_data.push(Info(CMD_QUIT, 0)); }

	void Print()
	{
		cout << "These are the commands you issued:" << endl << endl;
		while (!m_data.empty())
		{
			Info info = m_data.front();
			switch (info.cmd)
			{
			case CMD_ADV:
				cout << "advance " << info.moves << ", ";
				break;
			case CMD_LEFT:
				cout << "turn left, ";
				break;
			case CMD_RIGHT:
				cout << "turn right, ";
				break;
			case CMD_QUIT:
				cout << "quit" << endl;
				break;
			}
			m_data.pop();
		}
		cout << endl;
	}
};

///////////////////////
class CostReport
{
	queue<const TerrainInfo*> m_data;
	int m_commsCost, m_unclearedCost, m_uncleared;

public:
	CostReport() { m_commsCost = m_unclearedCost = m_uncleared = 0; }

	void AddCommsCost() { m_commsCost++; }
	void AddUnclearedCost(int cost) { m_unclearedCost += cost; m_uncleared++; }
	void AddCost(const TerrainInfo *info) { m_data.push(info); }

	void Print()
	{
		cout << endl << "The costs for this land clearing operation were:" << endl << endl;
		int fuelUsage = 0, protectedTree = 0, paintDamage = 0, otherCost = 0;
		while (!m_data.empty())
		{
			const TerrainInfo *info = m_data.front();
			fuelUsage += info->usage;
			switch (info->type)
			{
			case TERRAIN_TREE:
				paintDamage += info->cost;
				break;
			case TERRAIN_PTREE:
				protectedTree += info->cost;
				break;
			default:
				otherCost += info->cost;
				break;
			}
			m_data.pop();
		}

		int total = paintDamage + protectedTree + fuelUsage + m_commsCost + m_unclearedCost;

		cout << "Item						Quantity	Cost" << endl;
		cout << "communication overhead				" << m_commsCost << "		" << m_commsCost << endl;
		cout << "fuel usage					" << fuelUsage << "		" << fuelUsage << endl;
		cout << "uncleared squares				" << m_uncleared << "		" << m_unclearedCost << endl;
		cout << "destruction of protected tree			" << protectedTree << "		" << protectedTree << endl;
		cout << "paint damage to bulldozer			" << paintDamage << "		" << paintDamage << endl;
		cout << "----" << endl;
		cout << "Total								" << total << endl;

		cout << endl;
	}
};
