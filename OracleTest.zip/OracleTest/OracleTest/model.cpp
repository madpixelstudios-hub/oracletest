#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include "model.h"
#include "window.h"


Model::Model(const GLfloat *data, int size)
{
	glGenVertexArrays(1, &m_array);
	glBindVertexArray(m_array);

	// copy vertex data
	glGenBuffers(1, &m_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, m_buffer);
	glBufferData(GL_ARRAY_BUFFER, size, data, GL_STATIC_DRAW);

	m_count = size / (sizeof(GLfloat)*3);

	// identity
	m_world = mat4(1.0f);
}

Model::~Model()
{
	glDeleteProgram(m_program);
	glDeleteBuffers(1, &m_buffer);
	glDeleteVertexArrays(1, &m_array);
}

GLuint Model::LoadCode(const char *filename, bool vertex)
{
	string code;
	ifstream istream(filename, ifstream::in);
	if (!istream.is_open())
	{
		cout << stderr << ": Failed to open shader program: " << filename << endl;
		return -1;
	}

	std::stringstream sstr;
	sstr << istream.rdbuf();
	code = sstr.str();
	istream.close();
	char const* codeStr = code.c_str();

	GLuint id = glCreateShader(vertex ? GL_VERTEX_SHADER : GL_FRAGMENT_SHADER);
	glShaderSource(id, 1, &codeStr , NULL);
	glCompileShader(id);

	GLint res = GL_FALSE;
	glGetShaderiv(id, GL_COMPILE_STATUS, &res);
	int logLen;
	glGetShaderiv(id, GL_INFO_LOG_LENGTH, &logLen);
	if (logLen > 0)
	{
		char *errorMsg = new char[logLen+1];
		glGetShaderInfoLog(id, logLen, NULL, errorMsg);
		cout << errorMsg << endl;
		delete [] errorMsg;
		return -1;
	}

	return id;
}

void Model::CreateProgram(const char *name)
{
	string fn = name;
	fn += "_vp.txt";
	GLuint vp = LoadCode(fn.c_str(), true);
	if (vp == -1)
		return;
	fn = name;
	fn += "_fp.txt";
	GLuint fp = LoadCode(fn.c_str(), false);
	if (fp == -1)
		return;

	m_program = glCreateProgram();
	glAttachShader(m_program, vp);
	glAttachShader(m_program, fp);
	glLinkProgram(m_program);

	GLint res = GL_FALSE;
	glGetProgramiv(m_program, GL_COMPILE_STATUS, &res);
	int logLen;
	glGetProgramiv(m_program, GL_INFO_LOG_LENGTH, &logLen);
	if (logLen > 0)
	{
		char *errorMsg = new char[logLen+1];
		glGetProgramInfoLog(m_program, logLen, NULL, errorMsg);
		cout << errorMsg << endl;
		delete [] errorMsg;
	}

	glDetachShader(m_program, vp);
	glDetachShader(m_program, fp);
		
	glDeleteShader(vp);
	glDeleteShader(fp);
}


void Model::SetParam(const char *name, vec3 vec)
{
	glUseProgram(m_program);
	GLuint param = glGetUniformLocation(m_program, name);
	glUniform3fv(param, 1, &vec.x);
}

void Model::SetParam(const char *name, mat4 mat)
{
	glUseProgram(m_program);
	GLuint param = glGetUniformLocation(m_program, name);
	glUniformMatrix4fv(param, 1, GL_FALSE, &mat[0][0]);
}

void Model::Draw(Window *wgl)
{
	glUseProgram(m_program);

	mat4 wvp = wgl->GetProj() * wgl->GetView() *  m_world;
	SetParam("wvp", wvp);

	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, m_buffer);
	glVertexAttribPointer(
		0,                  // attribute id
		3,					// size
		GL_FLOAT,           // type
		GL_FALSE,           // normalized?
		0,                  // stride
		(void*)0            // array buffer offset
	);

	glDrawArrays(GL_TRIANGLE_STRIP, 0, m_count);

	glDisableVertexAttribArray(0);
}
