#pragma once

#include <iostream>
#include <string>

#include "opengl/glew.h"
#include "opengl/glfw3.h"
#include "opengl/glm/glm.hpp"
#include "opengl/glm/gtc/matrix_transform.hpp"

using namespace std;
using namespace glm;

const char CMD_ADV = 'a';
const char CMD_LEFT = 'l';
const char CMD_RIGHT = 'r';
const char CMD_QUIT = 'q';
const char CMD_CHECK = 'c';

struct TerrainInfo { char type; int usage, cost; vec3 color; };

const char TERRAIN_PLAIN = 'o';
const char TERRAIN_ROCK = 'r';
const char TERRAIN_TREE = 't';
const char TERRAIN_PTREE = 'T';
const char TERRAIN_VISIT = 'v';
