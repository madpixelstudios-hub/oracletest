#pragma once

#include "main.h"

class Window
{
	GLFWwindow *m_window;
	mat4 m_view, m_proj;

public:
	Window(const char *windowName, int width, int height, vec3 color);
	~Window();
	GLFWwindow *Get() { return m_window; }

	void SetView(mat4 mat) { m_view = mat; }
	void SetProj(mat4 mat) { m_proj = mat; }
	mat4 GetView() { return m_view; }
	mat4 GetProj() { return m_proj; }

	void StartFrame();
	void EndFrame();
};
