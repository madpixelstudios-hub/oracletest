// Test for Oracle
// Building Site Clearing Simulation
//
// David Serafim 12/06/2019
// Started: 15:11, Ended: 21:32 (30 min break)

#include <stdio.h>

#include "main.h"
#include "reports.h"
#include "terrain.h"

// my OpenGL implmentation stuff
#include "window.h"
#include "model.h"

int main( int argc, char *argv[] )
{
	if (argc < 2)
	{
		cout << "Error: Site Map data file not passed in!" << endl;
		return -1;
	}


	Terrain terrain;
	if (!terrain.OpenFile(argv[1]))
		return -1;

	CommandReport cmdReport;
	CostReport costReport;
	Bulldozer bull;

	Window *windowGL = NULL;
	if (argc == 3 && !strcmp(argv[2], "usegl"))
	{
		windowGL = new Window("Aconex Test", 600, 600, vec3(0,0,0.4f));

		// orthographic matrix
		const float scale = 30.f;
		mat4 projection = ortho(-scale/2,scale,-scale,scale/2,0.0f,scale*10.f);
		windowGL->SetProj(projection);

		// isometric view
		float twoPI = pi<float>() * 2.f;
		mat4 iso = mat4(vec4(sin(twoPI/3.f),cos(twoPI/3.f),0,0),
						vec4(sin(2.f*twoPI/3.f),cos(2.f*twoPI/3.f),0,0),
						vec4(0,1,1,0),
						vec4(0,0,0,1) );
		windowGL->SetView(iso);

		terrain.CreateModels();
		bull.CreateModels();
	}

	cout << "Welcome to the Aconex site clearing simulator. This is a map of the site:" << endl << endl;

	terrain.DrawMap(bull);

	cout << "The bulldozer is currently located at the Northern edge of the site, immediately to the West of the site, and facing East." << endl << endl;

	bool exit = false;
	while (!exit)
	{
		char command = 0;
		if (windowGL != NULL)
		{
			// use OpenGL
			windowGL->StartFrame();

			terrain.DrawMap(bull, windowGL);

			windowGL->EndFrame();

			// move bulldozer (use arrow keys)
			if (glfwGetKey(windowGL->Get(), GLFW_KEY_UP) == GLFW_PRESS)
				command = CMD_ADV;
			else if (glfwGetKey(windowGL->Get(), GLFW_KEY_LEFT) == GLFW_PRESS)
				command = CMD_LEFT;
			else if (glfwGetKey(windowGL->Get(), GLFW_KEY_RIGHT) == GLFW_PRESS)
				command = CMD_RIGHT;
			else if (glfwGetKey(windowGL->Get(), GLFW_KEY_ESCAPE) == GLFW_PRESS)
				command = CMD_QUIT;

			// read keys only once every half second
			static int slowdown = 0;
			if (slowdown++ >= 30 && command != 0)
				slowdown = 0;
			else
				command = 0;

			// check if user click window close
			if ( glfwWindowShouldClose(windowGL->Get()) != 0 )
				exit = true;
		}
		else
		{
			// get user input
			cout << "(l)eft, (r)ight, (a)dvance <n>, (q)uit: ";
			command = getchar();
			if (command != '\n')
				getchar();	// clear endl or space (in advance)
		}
		switch (command)
		{
		case CMD_ADV:
			{
				int steps = 1;
				if (windowGL == NULL)
				{
					char s[256];
					gets(s);
					steps = atoi(s);
					if (steps == 0)
					{
						cout << "Invalid advance parameter." << endl;
						break;
					}
				}
				cmdReport.Advance(steps);
				int ret = bull.Move(steps, terrain, costReport);
				if (ret == -1)
				{
					cout << endl << "The simulation has ended with bulldozer out of site bounds." << endl;
					exit = true;
				}
				else if (ret == -2)
				{
					cout << endl << "The simulation has ended with bulldozer removing protected tree." << endl;
					exit = true;
				}
				costReport.AddCommsCost();
			}
			break;
		case CMD_LEFT:
			cmdReport.Left();
			costReport.AddCommsCost();
			bull.TurnLeft();
			break;
		case CMD_RIGHT:
			cmdReport.Right();
			costReport.AddCommsCost();
			bull.TurnRight();
			break;
		case CMD_QUIT:
			cmdReport.Quit();
			cout << endl << "The simulation has ended at your request." << endl;
			exit = true;
			break;
		case CMD_CHECK:
			terrain.DrawMap(bull);
			break;
		default:
			if (windowGL == NULL)
				cout << "Invalid command." << endl;
			break;
		}
	}

	terrain.FindUncleared(costReport);

	cmdReport.Print();
	costReport.Print();

	if (windowGL != NULL)
		delete windowGL;

	cout << "Thankyou for using the Aconex site clearing simulator." << endl;

	return 0;
}
