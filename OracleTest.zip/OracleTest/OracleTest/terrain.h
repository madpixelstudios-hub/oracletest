#include <array>


///////////////////////
class Window;
class Model;
class Bulldozer;
class Terrain
{
	char *m_siteMap;
	int m_columns, m_rows;
	static const array<TerrainInfo, 5>  c_info;
	Model *m_square;

public:
	Terrain() { m_siteMap = NULL; m_square = NULL; }
	~Terrain();

	int GetColumns() { return m_columns; }
	int GetRows() { return m_rows; }

	bool OpenFile(char *fileName);
	void CreateModels();
	void DrawMap(Bulldozer &bull, Window *wgl=NULL);

	void Clear(int x, int y);
	char GetType(int x, int y);
	const TerrainInfo *GetInfo(int x, int y);

	int GetFuelUsage(int x, int y);

	void FindUncleared(CostReport &costRep);
};


///////////////////////
class Bulldozer
{
	static const char c_directions[4];
	int m_x, m_y;
	int m_dir;
	Model *m_arrow;

public:
	Bulldozer() { m_x = -1; m_y = 0; m_dir = 1; }
	~Bulldozer();

	int GetX() { return m_x; }
	int GetY() { return m_y; }
	int GetDir() { return m_dir; }

	void TurnLeft()
	{
		if (--m_dir < 0)
			m_dir = 3;
	}

	void TurnRight()
	{
		if (++m_dir > 3)
			m_dir = 0;
	}

	void CreateModels();
	void Draw(int c, int r, Window *wgl);

	int Move(int count, Terrain &terrain, CostReport &costRep);
};
