#include <iostream>

#include "window.h"


Window::Window(const char *windowName, int width, int height, vec3 color)
{
	// GL framework init
	if( !glfwInit() )
	{
		cout << stderr << "Failed to initialize GLFW." << endl;
		return;
	}

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // To make MacOS happy; should not be needed
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_COMPAT_PROFILE);

	// window with GL context
	m_window = glfwCreateWindow( width, height, windowName, NULL, NULL);
	if( m_window == NULL )
	{
		cout << stderr << "Failed to open GLFW window." << endl;
		glfwTerminate();
		return;
	}

	glfwMakeContextCurrent(m_window);

	// GL extention wrangler
	glewExperimental = true; // Needed for core profile
	if (glewInit() != GLEW_OK)
	{
		cout << stderr << "Failed to initialize GLEW." << endl;
		glfwTerminate();
		return;
	}

	// background color
	glClearColor(color.r,color.g,color.b,0);

	// set keyboard input
	glfwSetInputMode(m_window, GLFW_STICKY_KEYS, GL_FALSE);
}

Window::~Window()
{
	glfwTerminate();
}

void Window::StartFrame()
{
	glClear( GL_COLOR_BUFFER_BIT );
}

void Window::EndFrame()
{
	glfwSwapBuffers(m_window);
	glfwPollEvents();
}
